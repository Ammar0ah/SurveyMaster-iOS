//
//  Survey.swift
//  SurveyMaster
//
//  Created by Ammar Al-Helali on 6/4/19.
//  Copyright © 2019 Ammar Al-Helali. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
public class Survey {
    var id : String?
    var title : String?
    var date : Int?
    var description : String?
    var link : String?
    
    
}
