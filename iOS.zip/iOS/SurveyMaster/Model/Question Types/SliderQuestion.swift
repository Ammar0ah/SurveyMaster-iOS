//
//  SliderQuestion.swift
//  SurveyMaster
//
//  Created by Ammar Al-Helali on 6/25/19.
//  Copyright © 2019 Ammar Al-Helali. All rights reserved.
//

import Foundation


class SliderQuestion : Question {
  //var content = Content()
    override init(_ title: String, _ type: String) {
       super.init(title, type)
    }
}

